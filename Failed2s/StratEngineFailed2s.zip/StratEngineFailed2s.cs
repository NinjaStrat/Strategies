#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private ATRTrail[] cacheATRTrail;

		
		public ATRTrail ATRTrail(int fastATRPeriod, double fastATRMultiplier, int slowATRPeriod, double slowATRMultiplier, bool slowTrailTF, bool fastTrailTF)
		{
			return ATRTrail(Input, fastATRPeriod, fastATRMultiplier, slowATRPeriod, slowATRMultiplier, slowTrailTF, fastTrailTF);
		}


		
		public ATRTrail ATRTrail(ISeries<double> input, int fastATRPeriod, double fastATRMultiplier, int slowATRPeriod, double slowATRMultiplier, bool slowTrailTF, bool fastTrailTF)
		{
			if (cacheATRTrail != null)
				for (int idx = 0; idx < cacheATRTrail.Length; idx++)
					if (cacheATRTrail[idx].FastATRPeriod == fastATRPeriod && cacheATRTrail[idx].FastATRMultiplier == fastATRMultiplier && cacheATRTrail[idx].SlowATRPeriod == slowATRPeriod && cacheATRTrail[idx].SlowATRMultiplier == slowATRMultiplier && cacheATRTrail[idx].SlowTrailTF == slowTrailTF && cacheATRTrail[idx].FastTrailTF == fastTrailTF && cacheATRTrail[idx].EqualsInput(input))
						return cacheATRTrail[idx];
			return CacheIndicator<ATRTrail>(new ATRTrail(){ FastATRPeriod = fastATRPeriod, FastATRMultiplier = fastATRMultiplier, SlowATRPeriod = slowATRPeriod, SlowATRMultiplier = slowATRMultiplier, SlowTrailTF = slowTrailTF, FastTrailTF = fastTrailTF }, input, ref cacheATRTrail);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.ATRTrail ATRTrail(int fastATRPeriod, double fastATRMultiplier, int slowATRPeriod, double slowATRMultiplier, bool slowTrailTF, bool fastTrailTF)
		{
			return indicator.ATRTrail(Input, fastATRPeriod, fastATRMultiplier, slowATRPeriod, slowATRMultiplier, slowTrailTF, fastTrailTF);
		}


		
		public Indicators.ATRTrail ATRTrail(ISeries<double> input , int fastATRPeriod, double fastATRMultiplier, int slowATRPeriod, double slowATRMultiplier, bool slowTrailTF, bool fastTrailTF)
		{
			return indicator.ATRTrail(input, fastATRPeriod, fastATRMultiplier, slowATRPeriod, slowATRMultiplier, slowTrailTF, fastTrailTF);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.ATRTrail ATRTrail(int fastATRPeriod, double fastATRMultiplier, int slowATRPeriod, double slowATRMultiplier, bool slowTrailTF, bool fastTrailTF)
		{
			return indicator.ATRTrail(Input, fastATRPeriod, fastATRMultiplier, slowATRPeriod, slowATRMultiplier, slowTrailTF, fastTrailTF);
		}


		
		public Indicators.ATRTrail ATRTrail(ISeries<double> input , int fastATRPeriod, double fastATRMultiplier, int slowATRPeriod, double slowATRMultiplier, bool slowTrailTF, bool fastTrailTF)
		{
			return indicator.ATRTrail(input, fastATRPeriod, fastATRMultiplier, slowATRPeriod, slowATRMultiplier, slowTrailTF, fastTrailTF);
		}

	}
}

#endregion
