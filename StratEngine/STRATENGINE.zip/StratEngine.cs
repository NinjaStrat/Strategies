#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private ATRTrailingStop[] cacheATRTrailingStop;

		
		public ATRTrailingStop ATRTrailingStop(int period, double multi)
		{
			return ATRTrailingStop(Input, period, multi);
		}


		
		public ATRTrailingStop ATRTrailingStop(ISeries<double> input, int period, double multi)
		{
			if (cacheATRTrailingStop != null)
				for (int idx = 0; idx < cacheATRTrailingStop.Length; idx++)
					if (cacheATRTrailingStop[idx].Period == period && cacheATRTrailingStop[idx].Multi == multi && cacheATRTrailingStop[idx].EqualsInput(input))
						return cacheATRTrailingStop[idx];
			return CacheIndicator<ATRTrailingStop>(new ATRTrailingStop(){ Period = period, Multi = multi }, input, ref cacheATRTrailingStop);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.ATRTrailingStop ATRTrailingStop(int period, double multi)
		{
			return indicator.ATRTrailingStop(Input, period, multi);
		}


		
		public Indicators.ATRTrailingStop ATRTrailingStop(ISeries<double> input , int period, double multi)
		{
			return indicator.ATRTrailingStop(input, period, multi);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.ATRTrailingStop ATRTrailingStop(int period, double multi)
		{
			return indicator.ATRTrailingStop(Input, period, multi);
		}


		
		public Indicators.ATRTrailingStop ATRTrailingStop(ISeries<double> input , int period, double multi)
		{
			return indicator.ATRTrailingStop(input, period, multi);
		}

	}
}

#endregion
